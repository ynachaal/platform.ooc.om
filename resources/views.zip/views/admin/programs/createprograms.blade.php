@extends('layouts.admin')

@section('content')
<section class="content-header">
    <div class="container-fluid">
        <div class="row mb-2">
            <div class="col-sm-6">
                <h1>@lang('custom.programs')</h1>
            </div>
            <div class="col-sm-6">
                <ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item"><a href="#">@lang('custom.home')</a></li>
                    @if(isset($data))
                    <li class="breadcrumb-item active">@lang('custom.edit') @lang('custom.programs')</li>
                    @else
                    <li class="breadcrumb-item active">@lang('custom.create') @lang('custom.programs')</li>
                    @endif

                </ol>
            </div>
        </div>
    </div><!-- /.container-fluid -->
</section>
<section class="content">
    <div class="container-fluid">
        <div class="row">
            <!-- left column -->
            <div class="col-md-12">
                <!-- jquery validation -->
                <div class="card card-primary">
                    <div class="card-header">
                        @if(isset($data))
                        <h3 class="card-title">@lang('custom.edit') @lang('custom.programs')</h3>
                        @else
                        <h3 class="card-title">@lang('custom.create') @lang('custom.programs')</h3>
                        @endif
                    </div>
                    <!-- /.card-header -->
                    <!-- form start -->
                    <form role="form" id="newsForm" method="POST" action="{{ url('/programs/save') }}" enctype="multipart/form-data">
                        @csrf
                        <div class="card-body">
                            @if(isset($data))
                            <div class="form-group">
                                <input type="hidden" name="id" class="form-control" id="id" placeholder="Enter name" value="{{isset($data['id'])? $data['id'] : ""}}">
                            </div>
                            @endif
                            <div class="form-group">
                                <label for="exampleInputEmail1">@lang('custom.title')</label>
                                <input type="text" name="title" class="form-control" id="title" placeholder="@lang('custom.enter') @lang('custom.title')" value="{{isset($data['title']) ? $data['title'] : ''}}">
                            </div>
                            <div class="form-group">
                                    <label>Description</label>
                                    <textarea class="form-control" name="description" rows="3" placeholder="Enter ...">{{isset($data['description']) ? $data['description'] : ''}}</textarea>
                                </div>
                            <div class="form-group">
                                <label for="exampleInputEmail1">Forms</label>
                                <select name="form_id" class="form-control" >
                                    <option value="0" {{isset($data) && $data['form_id'] == 0 ? 'selected' : ''}}>Select</option>
                                    @foreach($forms as $forms)
                                        <option value="{{$forms['id']}}" {{isset($data) && $data['form_id'] == $forms['id'] ? 'selected' : ''}}>{{$forms['name']}}</option>
                                     @endforeach
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="exampleInputEmail1">parent</label>
                                <select name="parent_id" class="form-control" >
                                    <option value="0" {{isset($data) && $data['parent_id'] == 0 ? 'selected' : ''}}>Select</option>
                                    @foreach($programs as $programs)
                                        <option value="{{$programs['id']}}" {{isset($data) && $data['parent_id'] == $programs['id'] ? 'selected' : ''}}>{{$programs['title']}}</option>
                                     @endforeach
                                </select>
                            </div>
                            
                        </div>
                        <!-- /.card-body -->
                        <div class="card-footer">
                            @if(isset($data))
                            <button type="submit" class="btn btn-primary">@lang('custom.update')</button>
                            @else
                            <button type="submit" class="btn btn-primary">@lang('custom.save')</button>
                            @endif

                        </div>
                    </form>
                </div>
                <!-- /.card -->
            </div>
            <!--/.col (left) -->
            <!-- right column -->
            <div class="col-md-6">

            </div>
            <!--/.col (right) -->
        </div>
        <!-- /.row -->
    </div><!-- /.container-fluid -->
</section>


@endsection