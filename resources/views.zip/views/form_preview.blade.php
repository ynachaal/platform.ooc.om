@extends('layouts.admin')

@section('content')

@include('forms.'.$slug)

@endsection