@extends('layouts.guest')

@section('content')
<div class="login-box" style="width: 500px;">
    <div class="login-logo">
        <!-- <a href="#"><b>@lang('custom.app_name')</b></a> -->
        <a href="#"><img src="{{url('images/logo.png')}}" /></a>
    </div>
    <div class="login-logo">
        <strong style="font-size: 14px;">@lang('custom.login_welcome_header')</strong>
        <p style="font-size: 12px;" class="login-box-msg">@lang('custom.login_welcome_desc')</p>
    </div>
    <!-- /.login-logo -->
    <div class="card">
        <div class="card-body login-card-body">
            <form method="POST" action="{{ route('login') }}">
                @csrf
                <div class="input-group mb-3">
                    <input name="email" type="email" class="form-control @error('email') is-invalid @enderror" placeholder="@lang('custom.email_placeholder')">
                    <div class="input-group-append">
                        <div class="input-group-text">
                            <span class="fas fa-envelope"></span>
                        </div>
                    </div>
                    @error('email')
                    <span class="invalid-feedback" role="alert">
                        <!-- <strong>{{ $message }}</strong> -->
                        <strong>الرجاء إدخال البريد الإلكتروني</strong>
                    </span>
                    @enderror
                    @error('auth_failed')
                    <span style="display: block;" class="invalid-feedback" role="alert">
                        <strong>{{ $message }}</strong>
                    </span>
                    @enderror
                </div>
                <div class="input-group mb-3">
                    <input name="password" type="password" class="form-control @error('password') is-invalid @enderror" placeholder="@lang('custom.password_placeholder')">
                    <div class="input-group-append">
                        <div class="input-group-text">
                            <span class="fas fa-lock"></span>
                        </div>
                    </div>
                    @error('password')
                    <span class="invalid-feedback" role="alert">
                        <!-- <strong>{{ $message }}</strong> -->
                        <strong>الرجاء إدخال كملة السري</strong>
                    </span>
                    @enderror
                </div>
                <div class="row">
                    <!-- <div class="col-8">
                        <div class="icheck-primary">
                            <input type="checkbox" id="remember">
                            <label for="remember">
                                Remember Me
                            </label>
                        </div>
                    </div> -->
                    <!-- /.col -->
                    <div class="col-4">
                        <button type="submit" class="btn btn-primary btn-block">{{ __('Login') }}</button>
                    </div>
                    <!-- /.col -->
                </div>
            </form>

            <!-- <div class="social-auth-links text-center mb-3">
                <p>- OR -</p>
                <a href="#" class="btn btn-block btn-primary">
                    <i class="fab fa-facebook mr-2"></i> Sign in using Facebook
                </a>
                <a href="#" class="btn btn-block btn-danger">
                    <i class="fab fa-google-plus mr-2"></i> Sign in using Google+
                </a>
            </div> -->
            <!-- /.social-auth-links -->


            <!-- <p class="mb-1">
                <a href="#">@lang('custom.forgot_password')</a>
            </p> -->
            <!-- <p class="mb-1">
                @if(App::getLocale() == 'ar')
                <a href="{{ url('change-language/en') }}">
                    <img height="30" src="images/en.png" />
                </a>
                @else
                <a href="{{ url('change-language/ar') }}">
                    <img height="20" src="images/ar.png" />
                </a>
                @endif
            </p> -->
            <!-- <p class="mb-0">
                <a href="register.html" class="text-center">Register a new membership</a>
            </p> -->
        </div>
        <!-- /.login-card-body -->
    </div>
</div>
<!-- /.login-box -->
@endsection