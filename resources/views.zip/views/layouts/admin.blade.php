<!DOCTYPE html>
<html>

    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title>@lang('custom.app_name')</title>

        <!-- CSRF Token -->
        <meta name="csrf-token" content="{{ csrf_token() }}">

        <!-- Tell the browser to be responsive to screen width -->
        <meta name="viewport" content="width=device-width, initial-scale=1">
        @include('partials.css')
        @include('partials.js')

    </head>

    @php
    $dir = '';
    $sidebar = '';
    @endphp

    @if(App::getLocale() == 'ar')
    @php
    $dir = 'rtl';
    @endphp
    @endif

    @if(Auth::user()->hasRole('User'))
    @php
    //$sidebar = 'sidebar-collapse';
    @endphp
    @endif

    <body class="hold-transition sidebar-mini {{$sidebar}} {{$dir}}" dir="{{$dir}}">
        <div class="wrapper">

            @include('partials.nav')

            @include('partials.aside')

            <!-- Content Wrapper. Contains page content -->
            <div class="content-wrapper">
                @yield('content')
            </div>

            @include('partials.footer')

            <!-- Control Sidebar -->
            <aside class="control-sidebar control-sidebar-dark">
                <!-- Control sidebar content goes here -->
            </aside>
            <!-- /.control-sidebar -->
        </div>
        <!-- ./wrapper -->
        @include('partials.flash')

    </body>

</html>