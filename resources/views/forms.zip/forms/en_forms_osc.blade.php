<style>
    table {
  width:100%;
}
table, th, td {
  border: 1px solid black;
  border-collapse: collapse;
}
th, td {
  padding: 15px;
  /* text-align: left; */
}
#t01 tr:nth-child(even) {
  background-color: #eee;
}
#t01 tr:nth-child(odd) {
 background-color: #fff;
}
#t01 th {
  background-color: black;
  color: white;
}
.budget_proposal{
    width: 100%;
}
.budget{
    width: 100%;
}
.form-check-input {
    position: static;
    margin-right: 10px;
    margin-top: 8px;
}
</style>
<section class="content-header">
    <div class="container-fluid">
        <div class="row mb-2">
            <div class="col-sm-6">
                <h1>EN_Forms_OSC- المنح الأولمبية للمدربين</h1>
            </div>
            <div class="col-sm-6">
                <ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item"><a href="#">@lang('custom.home')</a></li>
                    <li class="breadcrumb-item active">{{ $slug }}</li>
                </ol>
            </div>
        </div>
    </div><!-- /.container-fluid -->
</section>
<section class="content">
    <div class="container-fluid">
        <div class="row">

            <div class="col-md-12">

                <div class="card card-primary">
                    <div class="card-header">
                        <h3 class="card-title">الرجاء تعبئة البيانات المطلوبة في الإستمارة</h3>
                    </div>
                    <!-- /.card-header -->
                    <!-- form start -->
                    <form role="form" id="quickForm" method="POST" action="{{ url('/forms/save_form1') }}">
                        @csrf

                        @if(isset($dataUserApplications))
                        <input type="hidden" name="dataUserApplicationsId" value="{{$dataUserApplications['id']}}" />
                        @endif

                        <div class="card-body">
                            <div class="form-group col-md-6">
                                <input type="hidden" name="application_id" class="form-control" placeholder="Committee Name" value="{{$application_id}}">
                            </div>
                            <p>IMPORTANT: This form duly completed and signed along with the documents indicated under “Attachments required” should be sent to Olympic Solidarity no later than 2 months before the start of the training. يجب ارسال هذا الطلب قبل مدة لا تقل عن شهرين من الموعد المحدد لتنفيذ البرنامج</p>
                            
                            <h3 class="form_header_2">CANDIDATE INFORMATION بيانات المرشح </h3>
                            <div class="col-md-12 row" style="margin-top: 20px;">
                                <div class="form-group col-md-6">
                                    <label for="exampleInputEmail1">Family Name اسم العائلة</label>
                                    <input type="text" name="family_name" class="form-control" placeholder="Family Name" value="{{isset($data['family_name'])? $data['family_name'] : ''}}">
                                </div>
                                <div class="form-group col-md-6">
                                    <label for="exampleInputEmail1">Given Name(s) الاسم الأول</label>
                                    <input type="text" name="given_name" class="form-control" placeholder="Given Name" value="{{isset($data['given_name'])? $data['given_name'] : ''}}">
                                </div>
                            </div>
                            <div class="col-md-12 row">
                                <div class="form-group col-md-6">
                                    <label for="exampleInputEmail1">Date of Birth تاريخ الميلاد </label>
                                    <input type="date" name="date_of_birth" class="form-control"  value="{{isset($data['date_of_birth'])? $data['date_of_birth'] : ''}}">
                                </div>
                                <div class="form-group col-md-6">
                                    <label for="exampleInputEmail1">Nationality الجنسية</label>
                                    <input type="text" name="nationality" class="form-control" placeholder="Nationality" value="{{isset($data['nationality'])? $data['nationality'] : ''}}">
                                </div>
                            </div>
                            <div class="col-md-12 row">
                                <div class="form-group col-md-6">
                                    <label for="exampleInputEmail1">Marital Statusالحالة الاجتماعية</label>
                                    <input type="radio" id="male" name="marital_status"  value="single" {{isset($data['marital_status']) && $data['marital_status']  == "single" ? 'checked' : ''}} >
                                    <label for="male">Single</label>
                                    <input type="radio" id="female" name="marital_status" value="married" {{isset($data['marital_status']) && $data['marital_status']  == "married" ? 'checked' : ''}}>
                                    <label for="female">Married</label>
                                </div>
                                <div class="form-group col-md-6">
                                    <label for="exampleInputEmail1">Genderالجنس</label>
                                    <input type="radio" id="male" name="gender"  value="male" {{isset($data['gender']) && $data['gender']  == "male" ? 'checked' : ''}} >
                                    <label for="male">Male</label>
                                    <input type="radio" id="female" name="gender" value="female" {{isset($data['gender']) && $data['gender']  == "female" ? 'checked' : ''}}>
                                    <label for="female">Female</label>
                                </div>
                            </div>
                            <div class="col-md-12 row" style="margin-top: 20px;">
                                <div class="form-group col-md-6">
                                    <label for="exampleInputEmail1">Residence الإقامة (المدينة / الدولة) (city, country)</label>
                                    <input type="text" name="residence" class="form-control" placeholder="Residence" value="{{isset($data['residence'])? $data['residence'] : ''}}">
                                </div>
                                <div class="form-group col-md-6">
                                    <label for="exampleInputEmail1">Emailالبريد الالكتروني </label>
                                    <input type="email" name="email" class="form-control" placeholder="Email" value="{{isset($data['email'])? $data['email'] : ''}}">
                                </div>
                            </div>
                            <div class="col-md-12 row" style="margin-top: 20px;">
                                <div class="form-group col-md-6">
                                <label for="exampleInputEmail1">Telephoneالهاتف  </label>
                                        <input type="number" name="telephone" class="form-control" placeholder="Telephone" value="{{isset($data['telephone'])? $data['telephone'] : ''}}">
                                </div>
                                <div class="form-group col-md-6">
                                <label for="exampleInputEmail1">Mobileالجوال </label>
                                        <input type="number" name="mobile" class="form-control" placeholder="Mobile" value="{{isset($data['mobile'])? $data['mobile'] : ''}}">
                                </div>
                            </div>
                                    
                            <div class="form-group col-md-12" style="margin-top: 20px;">
                                <label for="exampleInputEmail1">Sport (or other) الرياضة</label>
                                <input type="text" name="sport" class="form-control" placeholder="Sport (or other)" value="{{isset($data['sport'])? $data['sport'] : ''}}">
                            </div>
                            <div class="form-group col-md-12">
                                <label for="exampleInputEmail1">Discipline التخصص</label>
                                <input type="text" name="discipline" class="form-control" placeholder="Discipline" value="{{isset($data['discipline'])? $data['discipline'] : ''}}">
                            </div>
                            <div class="col-md-12 row">
                                <div class="form-group col-md-6">
                                    <label for="exampleInputEmail1">Active coachمدرب نشط </label>
                                    <input type="radio" id="yes" name="active_coach" style="margin-right: 20px;"  value="yes" {{isset($data['active_coach']) && $data['active_coach']  == "yes" ? 'checked' : ''}} >
                                    <label for="yes">yes</label>
                                    <input type="radio" id="no" name="active_coach" value="no" {{isset($data['active_coach']) && $data['active_coach']  == "no" ? 'checked' : ''}}>
                                    <label for="no">No</label>
                                </div>
                                <div class="form-group col-md-6">
                                    <label for="exampleInputEmail1">Latest اخر نشاط activity</label>
                                    <input type="date" id="latest_activity" name="latest_activity" class="form-control"   value="{{isset($data['latest_activity'])? $data['latest_activity'] : ''}}" >
                                </div>
                            </div>
                            
                            
                            <div class="col-md-12 row">
                                <div class="form-group col-md-6">
                                    <label for="exampleInputEmail1">Current Levelالمستوى الحالي</label>
                                    <br>
                                    <br>
                                    <input type="radio" id="current_level1" name="current_level" value="current_level1" {{isset($data['current_level']) && $data['current_level']  == "current_level1" ? 'checked' : ''}} >Level 1 (Coaching assistant)
                                    <!-- <label for="current_level1"></label> -->
                                    <br>
                                    <input type="radio" id="current_level2" name="current_level" value="current_level2" {{isset($data['current_level']) && $data['current_level']  == "current_level2" ? 'checked' : ''}}>Level 2 (Coach)
                                    <!-- <label for="current_leve2">Level 2 (Coach)</label> -->
                                    <br>
                                    <input type="radio" id="current_level3" name="current_level" value="current_level3" {{isset($data['current_level']) && $data['current_level']  == "current_level3" ? 'checked' : ''}}>Level 3 (advanced/senior coach)
                                    <!-- <label for="current_level3">Level 3 (advanced/senior coach)</label> -->
                                </div>
                                <!-- <div class="form-group col-md-6 col">
                                    <div class="row">
                                    <input class="form-check-input" type="checkbox" name="sport_for_all" value="sport_for_all" {{isset($data['sport_for_all']) && $data['sport_for_all']  =="sport_for_all" ? 'checked' : ''}}><label>for All<label>
                                    </div>
                                    <input class="form-check-input" type="checkbox" name="elite_sport" value="elite_sport" {{isset($data['elite_sport']) && $data['elite_sport']  =="elite_sport" ? 'checked' : ''}}>Elite Sport
                                </div> -->
                            </div>
                            
                            <h3 class="form_header_2">EDUCATION & Diplomas المستوى التعليمي والمؤهلات </h3>
                            <table style="margin-top: 20px;">
                                <tr>
                                    <th>Yearالسنة</th>
                                    <th>Trainingالتدريب</th>
                                    <th>Diplomas awardedالشهادة</th>
                                </tr>
                                <tr>
                                    <td class="p-0"><input type="text" name="year[0]" class="budget_proposal border-0" style="width: 100%;" value="{{isset($data['year'][0])? $data['year'][0] : ''}}"></td>
                                    <td class="p-0"><input type="text" name="training[0]" class="budget border-0" value="{{isset($data['training'][0])? $data['training'][0] : ''}}"></td>
                                    <td class="p-0"><input type="text" name="diplomas_awarded[0]" class="budget border-0" value="{{isset($data['diplomas_awarded'][0])? $data['diplomas_awarded'][0] : ''}}"></td>
                                </tr>
                                <tr>
                                    <td class="p-0"><input type="text" name="year[1]" class="budget_proposal border-0" style="width: 100%;" value="{{isset($data['year'][1])? $data['year'][1] : ''}}"></td>
                                    <td class="p-0"><input type="text" name="training[1]" class="budget border-0" value="{{isset($data['training'][1])? $data['training'][1] : ''}}"></td>
                                    <td class="p-0"><input type="text" name="diplomas_awarded[1]" class="budget border-0" value="{{isset($data['diplomas_awarded'][1])? $data['diplomas_awarded'][1] : ''}}"></td>
                                </tr>
                                <tr>
                                    <td class="p-0"><input type="text" name="year[2]" class="budget_proposal border-0" style="width: 100%;" value="{{isset($data['year'][2])? $data['year'][2] : ''}}"></td>
                                    <td class="p-0"><input type="text" name="training[2]" class="budget border-0" value="{{isset($data['training'][2])? $data['training'][2] : ''}}"></td>
                                    <td class="p-0"><input type="text" name="diplomas_awarded[2]" class="budget border-0" value="{{isset($data['diplomas_awarded'][2])? $data['diplomas_awarded'][2] : ''}}"></td>
                                </tr>
                            </table>

                            <h3 class="form_header_2">SPORTS EXPERIENCE الخبرات الرياضية  </h3>
                            <table style="margin-top: 20px;">
                                <tr>
                                    <th>Yearالسنة</th>
                                    <th>Clubs, athletes coached, past achievements, etc. أندية ، رياضيون مدربون ، إنجازات سابقة ، إلخ.</th>
                                </tr>
                                <tr>
                                    <td class="p-0"><input type="text" name="sports_year[0]" class="budget_proposal border-0" style="width: 100%;" value="{{isset($data['sports_year'][0])? $data['sports_year'][0] : ''}}"></td>
                                    <td class="p-0"><input type="text" name="sports_experience[0]" class="budget border-0" value="{{isset($data['sports_experience'][0])? $data['sports_experience'][0] : ''}}"></td>
                                </tr>
                                <tr>
                                    <td class="p-0"><input type="text" name="sports_year[1]" class="budget_proposal border-0" style="width: 100%;" value="{{isset($data['sports_year'][1])? $data['sports_year'][1] : ''}}"></td>
                                    <td class="p-0"><input type="text" name="sports_experience[1]" class="budget border-0" value="{{isset($data['sports_experience'][1])? $data['sports_experience'][1] : ''}}"></td>
                                </tr>
                                <tr>
                                    <td class="p-0"><input type="text" name="sports_year[2]" class="budget_proposal border-0" style="width: 100%;" value="{{isset($data['sports_year'][2])? $data['sports_year'][2] : ''}}"></td>
                                    <td class="p-0"><input type="text" name="sports_experience[2]" class="budget border-0" value="{{isset($data['sports_experience'][2])? $data['sports_experience'][2] : ''}}"></td>
                                </tr>
                            </table>

                            <table style="margin-top: 20px;">
                                <tr>
                                    <th>Yearالسنة</th>
                                    <th>Technical courses followed (OS & IF only) الدورات الفنية ( التضامن الأولمبي / الاتحاد الدولي )</th>
                                </tr>
                                <tr>
                                    <td class="p-0"><input type="text" name="technical_year[0]" class="budget_proposal border-0" style="width: 100%;" value="{{isset($data['technical_year'][0])? $data['technical_year'][0] : ''}}"></td>
                                    <td class="p-0"><input type="text" name="technical_courses[0]" class="budget border-0" value="{{isset($data['technical_courses'][0])? $data['technical_courses'][0] : ''}}"></td>
                                </tr>
                                <tr>
                                    <td class="p-0"><input type="text" name="technical_year[1]" class="budget_proposal border-0" style="width: 100%;" value="{{isset($data['technical_year'][1])? $data['technical_year'][1] : ''}}"></td>
                                    <td class="p-0"><input type="text" name="technical_courses[1]" class="budget border-0" value="{{isset($data['technical_courses'][1])? $data['technical_courses'][1] : ''}}"></td>
                                </tr>
                            </table>

                            <h3 class="form_header_2" style="margin-top: 20px;">LANGUAGE SKILLS اللغة </h3>

                            <table style="margin-top: 20px;">
                                <tr>
                                    <th>Language(s) اللغة</th>
                                    <th>Spoken تحدث</th>
                                    <th>Writtenالكتابة</th>
                                    <th>Readالقراءة</th>
                                </tr>
                                <tr>
                                    <td>1</td>
                                    <td>
                                        <input type="radio" id="spoken1" name="spoken[0]" style="margin-right: 20px;"  value="1" {{isset($data['spoken'][0]) && $data['spoken'][0]  == "1" ? 'checked' : ''}} >
                                        <label for="spoken1">1</label>
                                        <input type="radio" id="spoken2" name="spoken[0]" value="2" {{isset($data['spoken'][0]) && $data['spoken'][0]  == "2" ? 'checked' : ''}}>
                                        <label for="spoken2">2</label>
                                        <input type="radio" id="spoken3" name="spoken[0]" value="3" {{isset($data['spoken'][0]) && $data['spoken'][0]  == "3" ? 'checked' : ''}}>
                                        <label for="spoken3">3</label>
                                        <input type="radio" id="spoken4" name="spoken[0]" value="4" {{isset($data['spoken'][0]) && $data['spoken'][0]  == "4" ? 'checked' : ''}}>
                                        <label for="spoken4">4</label>
                                        <input type="radio" id="spoken5" name="spoken[0]" value="5" {{isset($data['spoken'][0]) && $data['spoken'][0] == "5" ? 'checked' : ''}}>
                                        <label for="spoken5">5</label>
                                    </td>
                                    <td>
                                        <input type="radio" id="written1" name="written[0]" style="margin-right: 20px;"  value="1" {{isset($data['written'][0]) && $data['written'][0]  == "1" ? 'checked' : ''}} >
                                        <label for="written1">1</label>
                                        <input type="radio" id="written2" name="written[0]" value="2" {{isset($data['written'][0]) && $data['written'][0]  == "2" ? 'checked' : ''}}>
                                        <label for="written2">2</label>
                                        <input type="radio" id="written3" name="written[0]" value="3" {{isset($data['written'][0]) && $data['written'][0]  == "3" ? 'checked' : ''}}>
                                        <label for="written3">3</label>
                                        <input type="radio" id="written4" name="written[0]" value="4" {{isset($data['written'][0]) && $data['written'][0]  == "4" ? 'checked' : ''}}>
                                        <label for="written4">4</label>
                                        <input type="radio" id="written5" name="written[0]" value="5" {{isset($data['written'][0]) && $data['written'][0]  == "5" ? 'checked' : ''}}>
                                        <label for="written5">5</label>
                                    </td>
                                    <td>
                                        <input type="radio" id="read1" name="read[0]" style="margin-right: 20px;"  value="1" {{isset($data['read'][0]) && $data['read'][0]  == "1" ? 'checked' : ''}} >
                                        <label for="read1">1</label>
                                        <input type="radio" id="read2" name="read[0]" value="2" {{isset($data['read'][0]) && $data['read'][0]  == "2" ? 'checked' : ''}}>
                                        <label for="read2">2</label>
                                        <input type="radio" id="read3" name="read[0]" value="3" {{isset($data['read'][0]) && $data['read'][0]  == "3" ? 'checked' : ''}}>
                                        <label for="read3">3</label>
                                        <input type="radio" id="read4" name="read[0]" value="4" {{isset($data['read'][0]) && $data['read'][0]  == "4" ? 'checked' : ''}}>
                                        <label for="read4">4</label>
                                        <input type="radio" id="read5" name="read[0]" value="5" {{isset($data['read'][0]) && $data['read'][0]  == "5" ? 'checked' : ''}}>
                                        <label for="read5">5</label>
                                    </td>
                                </tr>
                                <tr>
                                    <td>2</td>
                                    <td>
                                        <input type="radio" id="spoken1" name="spoken[1]" style="margin-right: 20px;"  value="1" {{isset($data['spoken'][1]) && $data['spoken'][1]  == "1" ? 'checked' : ''}} >
                                        <label for="spoken1">1</label>
                                        <input type="radio" id="spoken2" name="spoken[1]" value="2" {{isset($data['spoken'][1]) && $data['spoken'][1]  == "2" ? 'checked' : ''}}>
                                        <label for="spoken2">2</label>
                                        <input type="radio" id="spoken3" name="spoken[1]" value="3" {{isset($data['spoken'][1]) && $data['spoken'][1]  == "3" ? 'checked' : ''}}>
                                        <label for="spoken3">3</label>
                                        <input type="radio" id="spoken4" name="spoken[1]" value="4" {{isset($data['spoken'][1]) && $data['spoken'][1]  == "4" ? 'checked' : ''}}>
                                        <label for="spoken4">4</label>
                                        <input type="radio" id="spoken5" name="spoken[1]" value="5" {{isset($data['spoken'][1]) && $data['spoken'][1] == "5" ? 'checked' : ''}}>
                                        <label for="spoken5">5</label>
                                    </td>
                                    <td>
                                        <input type="radio" id="written1" name="written[1]" style="margin-right: 20px;"  value="1" {{isset($data['written'][1]) && $data['written'][1]  == "1" ? 'checked' : ''}} >
                                        <label for="written1">1</label>
                                        <input type="radio" id="written2" name="written[1]" value="2" {{isset($data['written'][1]) && $data['written'][1]  == "2" ? 'checked' : ''}}>
                                        <label for="written2">2</label>
                                        <input type="radio" id="written3" name="written[1]" value="3" {{isset($data['written'][1]) && $data['written'][1]  == "3" ? 'checked' : ''}}>
                                        <label for="written3">3</label>
                                        <input type="radio" id="written4" name="written[1]" value="4" {{isset($data['written'][1]) && $data['written'][1]  == "4" ? 'checked' : ''}}>
                                        <label for="written4">4</label>
                                        <input type="radio" id="written5" name="written[1]" value="5" {{isset($data['written'][1]) && $data['written'][1]  == "5" ? 'checked' : ''}}>
                                        <label for="written5">5</label>
                                    </td>
                                    <td>
                                        <input type="radio" id="read1" name="read[1]" style="margin-right: 20px;"  value="1" {{isset($data['read'][1]) && $data['read'][1]  == "1" ? 'checked' : ''}} >
                                        <label for="read1">1</label>
                                        <input type="radio" id="read2" name="read[1]" value="2" {{isset($data['read'][1]) && $data['read'][1]  == "2" ? 'checked' : ''}}>
                                        <label for="read2">2</label>
                                        <input type="radio" id="read3" name="read[1]" value="3" {{isset($data['read'][1]) && $data['read'][1]  == "3" ? 'checked' : ''}}>
                                        <label for="read3">3</label>
                                        <input type="radio" id="read4" name="read[1]" value="4" {{isset($data['read'][1]) && $data['read'][1]  == "4" ? 'checked' : ''}}>
                                        <label for="read4">4</label>
                                        <input type="radio" id="read5" name="read[1]" value="5" {{isset($data['read'][1]) && $data['read'][1]  == "5" ? 'checked' : ''}}>
                                        <label for="read5">5</label>
                                    </td>
                                </tr>
                                <tr>
                                    <td>3</td>
                                    <td>
                                        <input type="radio" id="spoken1" name="spoken[2]" style="margin-right: 20px;"  value="1" {{isset($data['spoken'][2]) && $data['spoken'][2]  == "1" ? 'checked' : ''}} >
                                        <label for="spoken1">1</label>
                                        <input type="radio" id="spoken2" name="spoken[2]" value="2" {{isset($data['spoken'][2]) && $data['spoken'][2]  == "2" ? 'checked' : ''}}>
                                        <label for="spoken2">2</label>
                                        <input type="radio" id="spoken3" name="spoken[2]" value="3" {{isset($data['spoken'][2]) && $data['spoken'][2]  == "3" ? 'checked' : ''}}>
                                        <label for="spoken3">3</label>
                                        <input type="radio" id="spoken4" name="spoken[2]" value="4" {{isset($data['spoken'][2]) && $data['spoken'][2]  == "4" ? 'checked' : ''}}>
                                        <label for="spoken4">4</label>
                                        <input type="radio" id="spoken5" name="spoken[2]" value="5" {{isset($data['spoken'][2]) && $data['spoken'][2] == "5" ? 'checked' : ''}}>
                                        <label for="spoken5">5</label>
                                    </td>
                                    <td>
                                        <input type="radio" id="written1" name="written[2]" style="margin-right: 20px;"  value="1" {{isset($data['written'][2]) && $data['written'][2]  == "1" ? 'checked' : ''}} >
                                        <label for="written1">1</label>
                                        <input type="radio" id="written2" name="written[2]" value="2" {{isset($data['written'][2]) && $data['written'][2]  == "2" ? 'checked' : ''}}>
                                        <label for="written2">2</label>
                                        <input type="radio" id="written3" name="written[2]" value="3" {{isset($data['written'][2]) && $data['written'][2]  == "3" ? 'checked' : ''}}>
                                        <label for="written3">3</label>
                                        <input type="radio" id="written4" name="written[2]" value="4" {{isset($data['written'][2]) && $data['written'][2]  == "4" ? 'checked' : ''}}>
                                        <label for="written4">4</label>
                                        <input type="radio" id="written5" name="written[2]" value="5" {{isset($data['written'][2]) && $data['written'][2]  == "5" ? 'checked' : ''}}>
                                        <label for="written5">5</label>
                                    </td>
                                    <td>
                                        <input type="radio" id="read1" name="read[3]" style="margin-right: 20px;"  value="1" {{isset($data['read'][3]) && $data['read'][3]  == "1" ? 'checked' : ''}} >
                                        <label for="read1">1</label>
                                        <input type="radio" id="read2" name="read[3]" value="2" {{isset($data['read'][3]) && $data['read'][3]  == "2" ? 'checked' : ''}}>
                                        <label for="read2">2</label>
                                        <input type="radio" id="read3" name="read[3]" value="3" {{isset($data['read'][3]) && $data['read'][3]  == "3" ? 'checked' : ''}}>
                                        <label for="read3">3</label>
                                        <input type="radio" id="read4" name="read[3]" value="4" {{isset($data['read'][3]) && $data['read'][3]  == "4" ? 'checked' : ''}}>
                                        <label for="read4">4</label>
                                        <input type="radio" id="read5" name="read[3]" value="5" {{isset($data['read'][3]) && $data['read'][3]  == "5" ? 'checked' : ''}}>
                                        <label for="read5">5</label>
                                    </td>
                                </tr>
                            </table>

                            <h3 class="form_header_2" style="margin-top: 20px;">information ABOUT THE TRAINING بيانات حول التدريب</h3>
                            <table style="margin-top: 20px;">
                                <tr>
                                    <td>Option chosen الخيارات المتاح </td>
                                    <td>
                                        <div class="row">
                                            Training in sports sciences
                                            <input class="form-check-input" type="checkbox" name="training_sports_sciences" value="training_sports_sciences" {{isset($data['training_sports_sciences']) && $data['training_sports_sciences']  =="training_sports_sciences" ? 'checked' : ''}}>
                                        </div>
                                    </td>
                                </tr>

                                <tr>
                                    <td></td>
                                    <td>
                                        <div class="row">
                                            Sports specific training
                                            <input class="form-check-input" type="checkbox" name="sports_specific_training" value="sports_specific_training" {{isset($data['sports_specific_training']) && $data['sports_specific_training']  =="sports_specific_training" ? 'checked' : ''}}>
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <td></td>
                                    <td>
                                        <div class="row">
                                            Distance training
                                            <input class="form-check-input" type="checkbox" name="distance_training" value="distance_training" {{isset($data['distance_training']) && $data['distance_training']  =="distance_training" ? 'checked' : ''}}>
                                        </div>
                                    </td>
                                </tr>
                            </table>
                            <div class="col-md-12 row" style="margin-top: 20px;">
                                <div class="form-group col-md-6">
                                    <label for="exampleInputEmail1">Centre/University المركز / الجامعة </label>
                                    <input type="text" name="centre_university" class="form-control" placeholder="Centre/University" value="{{isset($data['centre_university'])? $data['centre_university'] : ''}}">
                                </div>
                                <div class="form-group col-md-6">
                                    <label for="exampleInputEmail1">Venue المكان</label>
                                    <input type="text" name="venue" class="form-control" placeholder="Venue" value="{{isset($data['venue'])? $data['venue'] : ''}}">
                                </div>
                            </div>
                            <div class="col-md-12 row" style="margin-top: 20px;">
                                <div class="form-group col-md-6">
                                    <label for="exampleInputEmail1">Websiteالموقع الالكتروني </label>
                                    <input type="text" name="website" class="form-control" placeholder="Website" value="{{isset($data['website'])? $data['website'] : ''}}">
                                </div>
                                <div class="form-group col-md-6">
                                    <label for="exampleInputEmail1">Streetالشارع</label>
                                    <input type="text" name="street" class="form-control" placeholder="Street" value="{{isset($data['street'])? $data['street'] : ''}}">
                                </div>
                            </div>
                            <div class="col-md-12 row" style="margin-top: 20px;">
                                <div class="form-group col-md-6">
                                    <label for="exampleInputEmail1">Cityالمدينة </label>
                                    <input type="text" name="city" class="form-control" placeholder="City" value="{{isset($data['city'])? $data['city'] : ''}}">
                                </div>
                                <div class="form-group col-md-6">
                                    <label for="exampleInputEmail1">Countryالدولة</label>
                                    <input type="text" name="country" class="form-control" placeholder="Country" value="{{isset($data['country'])? $data['country'] : ''}}">
                                </div>
                            </div>
                            <div class="form-group col-md-12">
                                <label for="exampleInputEmail1">Course/Seminarدورة / ندوة (exact title)</label>
                                <input type="text" name="course_seminar" class="form-control" placeholder="course seminar" value="{{isset($data['course_seminar'])? $data['course_seminar'] : ''}}">
                            </div>
                            <div class="form-group col-md-12">
                                <label for="exampleInputEmail1">Length of the course مدة البرنامج</label>
                                <div class="row">
                                    <div class="col-md-5 row">
                                        <label style="margin-right: 20px;" for="length_start_date"> Start Dateالبداية</label>
                                        <input type="date" id="length_start_date" name="length_start_date" class="form-control col-md-10" style="margin-right: 20px;"  value="{{isset($data['length_start_date'])? $data['length_start_date'] : ''}}" >
                                    </div>
                                    <div class="ml-2 mr-2 col-md-5 row">
                                        <label style="margin-right: 20px;" for="length_end_date">End Date النهاية</label>
                                        <input type="date" id="length_end_date" name="length_end_date" class="form-control col-md-10" style="margin-right: 20px;" value="{{isset($data['length_end_date'])? $data['length_end_date'] : ''}}">
                                    </div>
                                </div>
                            </div>
                            <div class="form-group col-md-12">
                                <label for="exampleInputEmail1">Final qualificationالمؤهل النهائي (الشهاداة ، الدبلوم) (diploma, certificate)</label>
                                <input type="text" name="final_qualification" class="form-control" placeholder="final_qualification" value="{{isset($data['final_qualification'])? $data['final_qualification'] : ''}}">
                            </div>

                            <h3 class="form_header_2" style="margin-top: 20px;">Contact person within the centre/universityبيانات التواصل لشخص من الجامعة / المركز</h3>
                            <div class="col-md-12 row" style="margin-top: 20px;">
                                <div class="form-group col-md-6">
                                    <label for="exampleInputEmail1">Family Name اسم العائلة</label>
                                    <input type="text" name="contact_family_name" class="form-control" placeholder="Family Name" value="{{isset($data['contact_family_name'])? $data['contact_family_name'] : ''}}">
                                </div>
                                <div class="form-group col-md-6">
                                    <label for="exampleInputEmail1">Given Name(s) الاسم الأول</label>
                                    <input type="text" name="contact_given_name" class="form-control" placeholder="Given Name" value="{{isset($data['contact_given_name'])? $data['contact_given_name'] : ''}}">
                                </div>
                            </div>

                            <div class="col-md-12 row" style="margin-top: 20px;">
                                <div class="form-group col-md-6">
                                    <label for="exampleInputEmail1">Emailالبريد الالكتروني</label>
                                    <input type="text" name="contact_email" class="form-control" placeholder="Email" value="{{isset($data['contact_email'])? $data['contact_email'] : ''}}">
                                </div>
                                <div class="form-group col-md-6">
                                    <label for="exampleInputEmail1">Telephoneالهاتف</label>
                                    <input type="text" name="contact_telephone" class="form-control" placeholder="Telephone" value="{{isset($data['contact_telephone'])? $data['contact_telephone'] : ''}}">
                                </div>
                            </div>

                            <h3 class="form_header_2" style="margin-top: 20px;">Budget proposal الموازنة المقترحة</h3>

                            <table style="margin-top: 20px;">
                                <tr>
                                    <th>Type of expenditureالبند</th>
                                    <th> المبلغ Budget (LOC)</th>
                                </tr>
                                <tr>
                                    <td>Estimated cost of the air ticket (mandatory)</td>
                                    <td class="p-0"><input type="text" name="budget[0]" class="budget border-0" value="{{isset($data['budget'][0])? $data['budget'][0] : ''}}"></td>
                                </tr>
                                <tr>
                                    <td class="p-0"><input type="text" name="type_of_expenditure[1]" class="budget border-0" value="{{isset($data['type_of_expenditure'][1])? $data['type_of_expenditure'][1] : ''}}"></td>
                                    <td class="p-0"><input type="text" name="budget[1]" class="budget border-0" value="{{isset($data['budget'][1])? $data['budget'][1] : ''}}"></td>
                                </tr>
                                <tr>
                                    <td class="p-0"><input type="text" name="type_of_expenditure[2]" class="budget border-0" value="{{isset($data['type_of_expenditure'][2])? $data['type_of_expenditure'][2] : ''}}"></td>
                                    <td class="p-0"><input type="text" name="budget[2]" class="budget border-0" value="{{isset($data['budget'][2])? $data['budget'][2] : ''}}"></td>
                                </tr>
                                <tr>
                                    <td class="p-0"><input type="text" name="type_of_expenditure[3]" class="budget border-0" value="{{isset($data['type_of_expenditure'][3])? $data['type_of_expenditure'][3] : ''}}"></td>
                                    <td class="p-0"><input type="text" name="budget[3]" class="budget border-0" value="{{isset($data['budget'][3])? $data['budget'][3] : ''}}"></td>
                                </tr>
                                <tr>
                                    <td class="p-0"><input type="text" name="type_of_expenditure[4]" class="budget border-0" value="{{isset($data['type_of_expenditure'][4])? $data['type_of_expenditure'][4] : ''}}"></td>
                                    <td class="p-0"><input type="text" name="budget[4]" class="budget border-0" value="{{isset($data['budget'][4])? $data['budget'][4] : ''}}"></td>
                                </tr>
                                <tr>
                                    <td class="p-0"><input type="text" name="type_of_expenditure[5]" class="budget border-0" value="{{isset($data['type_of_expenditure'][5])? $data['type_of_expenditure'][5] : ''}}"></td>
                                    <td class="p-0"><input type="text" name="budget[5]" class="budget border-0" value="{{isset($data['budget'][5])? $data['budget'][5] : ''}}"></td>
                                </tr>
                                <tr>
                                    <td class="p-0"><input type="text" name="type_of_expenditure[6]" class="budget border-0" value="{{isset($data['type_of_expenditure'][6])? $data['type_of_expenditure'][6] : ''}}"></td>
                                    <td class="p-0"><input type="text" name="budget[6]" class="budget border-0" value="{{isset($data['budget'][6])? $data['budget'][6] : ''}}"></td>
                                </tr>
                                <tr>
                                    <td class="p-0"><input type="text" name="type_of_expenditure[7]" class="budget border-0" value="{{isset($data['type_of_expenditure'][7])? $data['type_of_expenditure'][7] : ''}}"></td>
                                    <td class="p-0"><input type="text" name="budget[7]" class="budget border-0" value="{{isset($data['budget'][7])? $data['budget'][7] : ''}}"></td>
                                </tr>
                                <tr>
                                    <td>Total</td>
                                    <td class="p-0"><input type="text" name="total_budget" class="budget border-0" value="{{isset($data['total_budget'])? $data['total_budget'] : ''}}"></td>
                                </tr>
                            </table>

                            <h3 class="form_header_2" style="margin-top: 20px;">ATTACHMENTS REQUIRED المرفقات المقترحة </h3>
                            <table style="margin-top: 20px;">
                                <tr>
                                    <td>Curriculum Vitae السيرة الذاتية </td>
                                    <td>
                                        <div class="row">
                                        تحميل مرفق
                                        <input class="form-check-input" type="checkbox" name="curriculum_vitae" value="curriculum_vitae" {{isset($data['curriculum_vitae']) && $data['curriculum_vitae']  =="curriculum_vitae" ? 'checked' : ''}}>
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <td>Medical certificate (validity: less than 3 months prior to the application)شهادة طبية (في مدة أقصاها 3 اشهر قبل تقديم الطلب ) </td>
                                    <td>
                                        <div class="row">
                                        تحميل مرفق <input class="form-check-input" type="checkbox" name="medical_certificate" value="medical_certificate" {{isset($data['medical_certificate']) && $data['medical_certificate']  =="medical_certificate" ? 'checked' : ''}}>
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <td>Support letter from the NF خطاب تزكية من الاتحاد/اللجنة  المعني  </td>
                                    <td> 
                                        <div class="row">
                                        تحميل مرفق <input class="form-check-input" type="checkbox" name="support_letter" value="support_letter" {{isset($data['support_letter']) && $data['support_letter']  =="support_letter" ? 'checked' : ''}}></div>
                                    </td>
                                </tr>
                                <tr>
                                    <td>Copy of passport نسخة من جواز السفر  </td>
                                    <td> <div class="row">تحميل مرفق <input class="form-check-input" type="checkbox" name="passport" value="passport" {{isset($data['passport']) && $data['passport']  =="passport" ? 'checked' : ''}}></div></td>
                                </tr>
                                <tr>
                                    <td>Covering letter from the candidate خطاب تغطية من المترشح  </td>
                                    <td> <div class="row">تحميل مرفق <input class="form-check-input" type="checkbox" name="covering_letter" value="covering_letter" {{isset($data['covering_letter']) && $data['covering_letter']  =="covering_letter" ? 'checked' : ''}}></div></td>
                                </tr>
                                <tr>
                                    <td>Acceptance letter from the centre/university/IF خطاب قبول من المركز / الجامعة </td>
                                    <td> <div class="row">تحميل مرفق <input class="form-check-input" type="checkbox" name="acceptance_letter" value="acceptance_letter" {{isset($data['acceptance_letter']) && $data['acceptance_letter']  =="acceptance_letter" ? 'checked' : ''}}></div></td>
                                </tr>
                                <tr>
                                    <td>For the sport-specific training: detailed description of the training course & budgetوصف مفصل للدورة التدريبية والميزانية</td>
                                    <td> <div class="row">تحميل مرفق <input class="form-check-input" type="checkbox" name="sport_specific_training" value="sport_specific_training" {{isset($data['sport_specific_training']) && $data['sport_specific_training']  =="sport_specific_training" ? 'checked' : ''}}></div></td>
                                </tr>
                            </table>
                        </div>
                        <!-- /.card-body -->
                        <div class="card-footer">
                            @if (( \Auth::user()->hasAnyRole(['User']) && !isset($data) ) || (\Auth::user()->hasAnyRole(['User']) && (isset($dataUserApplications) && $dataUserApplications['status'] == 'request not completed')))
                                @if(isset($data))
                                <button type="submit" class="btn btn-primary">@lang('custom.update')</button>
                                @else
                                <button type="submit" class="btn btn-primary">@lang('custom.save')</button>
                                @endif
                            @endif
                        </div>
                    </form>
                </div>

            </div>

            
        </div>

    </div>
</section>