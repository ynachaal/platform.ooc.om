<style>
    table {
  width:100%;
}
table, th, td {
  border: 1px solid black;
  border-collapse: collapse;
}
th, td {
  padding: 15px;
  /* text-align: left; */
}
#t01 tr:nth-child(even) {
  background-color: #eee;
}
#t01 tr:nth-child(odd) {
 background-color: #fff;
}
#t01 th {
  background-color: black;
  color: white;
}
.budget_proposal{
    width: 100%;
}
.budget{
    width: 100%;
}
.form-check-input {
    position: static;
    margin-right: 10px;
    margin-top: 8px;
}
</style>
<section class="content-header">
    <div class="container-fluid">
        <div class="row mb-2">
            <div class="col-sm-6">
                <h1>Development National Sports System</h1>
            </div>
            <div class="col-sm-6">
                <ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item"><a href="#">@lang('custom.home')</a></li>
                    <li class="breadcrumb-item active">{{ $slug }}</li>
                </ol>
            </div>
        </div>
    </div><!-- /.container-fluid -->
</section>
<section class="content">
    <div class="container-fluid">
        <div class="row">

            <div class="col-md-12">

                <div class="card card-primary">
                    <div class="card-header">
                        <h3 class="card-title">الرجاء تعبئة البيانات المطلوبة في الإستمارة</h3>
                    </div>
                    <!-- /.card-header -->
                    <!-- form start -->
                    <form role="form" id="quickForm" method="POST" action="{{ url('/forms/save_form1') }}">
                        @csrf

                        @if(isset($dataUserApplications))
                        <input type="hidden" name="dataUserApplicationsId" value="{{$dataUserApplications['id']}}" />
                        @endif

                        <div class="card-body">
                            <div class="form-group col-md-6">
                                <input type="hidden" name="application_id" class="form-control" placeholder="Committee Name" value="{{$application_id}}">
                            </div>
                            <p>IMPORTANT: This form duly completed and signed along with the documents indicated under “Attachments required” should be sent to Olympic Solidarity no later than 3 months before the start of your action plan.</p>
                            <p>يجب ارسال هذا الطلب قبل مدة لا تقل عن 3 اشهر من الموعد المحدد لتنفيذ البرنامج</p>
                            
                            <div class="form-group col-md-12" style="margin-top: 20px;">
                                <label for="exampleInputEmail1">Sport (or other) الرياضة</label>
                                <input type="text" name="sport" class="form-control" placeholder="Sport (or other)" value="{{isset($data['sport'])? $data['sport'] : ''}}">
                            </div>
                            <div class="form-group col-md-12">
                                <label for="exampleInputEmail1">Discipline التخصص</label>
                                <input type="text" name="discipline" class="form-control" placeholder="Discipline" value="{{isset($data['discipline'])? $data['discipline'] : ''}}">
                            </div>
                            <div class="form-group col-md-12">
                                <label for="exampleInputEmail1">Name of the project (if any) اسم المشروع</label>
                                <input type="text" name="name_of_project" class="form-control" placeholder="Name of the project" value="{{isset($data['name_of_project'])? $data['name_of_project'] : ''}}">
                            </div>

                            <h3 class="form_header_2" style="margin-top: 20px;">CURRENT SPORT STRUCTURE الهيكل الرياضي الحالي  </h3>

                            <div class="form-group col-md-12">
                                <label for="exampleInputEmail1" style="margin-top: 20px;">Summary of the current level ملخص المستوى الحالي </label>
                                <textarea class="form-control"  name ="summary_current_level" style="width: 100%; height: 200px; font-size: 14px; line-height: 18px; border: 1px solid #dddddd; padding: 10px;">{{isset($data['summary_current_level']) ? $data['summary_current_level'] : ''}}</textarea>
                            </div>
                            <div class="form-group col-md-12">
                                <label for="exampleInputEmail1" style="margin-top: 20px;">Weak points نقاط الضعف </label>
                                <textarea class="form-control"  name ="weak_points" style="width: 100%; height: 200px; font-size: 14px; line-height: 18px; border: 1px solid #dddddd; padding: 10px;">{{isset($data['weak_points']) ? $data['weak_points'] : ''}}</textarea>
                            </div>
                            <div class="form-group col-md-12">
                                <label for="exampleInputEmail1" style="margin-top: 20px;">Strong points نقاط القوة </label>
                                <textarea class="form-control"  name ="strong_points" style="width: 100%; height: 200px; font-size: 14px; line-height: 18px; border: 1px solid #dddddd; padding: 10px;">{{isset($data['strong_points']) ? $data['strong_points'] : ''}}</textarea>
                            </div>
                            <div class="form-group col-md-12">
                                <label for="exampleInputEmail1" style="margin-top: 20px;">Analysis of requirements تحليل المتطلبات </label>
                                <textarea class="form-control"  name ="analysis_of_requirements" style="width: 100%; height: 200px; font-size: 14px; line-height: 18px; border: 1px solid #dddddd; padding: 10px;">{{isset($data['analysis_of_requirements']) ? $data['analysis_of_requirements'] : ''}}</textarea>
                            </div>
                            <div class="form-group col-md-12">
                                <label for="exampleInputEmail1" style="margin-top: 20px;">Action plan proposed خطة العمل المقترحة </label>
                                <textarea class="form-control"  name ="action_plan_proposed" style="width: 100%; height: 200px; font-size: 14px; line-height: 18px; border: 1px solid #dddddd; padding: 10px;">{{isset($data['action_plan_proposed']) ? $data['action_plan_proposed'] : ''}}</textarea>
                            </div>
                            <div class="form-group col-md-12">
                                <label for="exampleInputEmail1" style="margin-top: 20px;">Objectives / expected results الأهداف / النتائج  المتوقعة </label>
                                <textarea class="form-control"  name ="objectives_expected_results" style="width: 100%; height: 200px; font-size: 14px; line-height: 18px; border: 1px solid #dddddd; padding: 10px;">{{isset($data['objectives_expected_results']) ? $data['objectives_expected_results'] : ''}}</textarea>
                            </div>

                            <h3 class="form_header_2" style="margin-top: 20px;">PLANNING التخطيط </h3>

                            <div class="form-group col-md-12">
                                <label for="exampleInputEmail1">Length of the programme مدة البرنامج</label>
                                <br>
                                <div class="row mt-2">
                                    <div class="col-md-5 row">
                                        <label style="margin-right: 20px;" class="col-md-6" for="length_start_date"> Start Dateالبداية</label>
                                        <input type="date" id="length_start_date" name="length_start_date" class="form-control col-md-8" style="margin-right: 20px;"  value="{{isset($data['length_start_date'])? $data['length_start_date'] : ''}}" >
                                    </div>
                                    <div class="ml-2 mr-2 col-md-5 row">
                                        <label style="margin-right: 20px;" class="col-md-6" for="length_end_date">End Date النهاية</label>
                                        <input type="date" id="length_end_date" name="length_end_date" class="form-control col-md-8" style="margin-right: 20px;" value="{{isset($data['length_end_date'])? $data['length_end_date'] : ''}}">
                                    </div>
                                </div>
                            </div>
                            <div class="form-group col-md-12">
                                <label for="exampleInputEmail1">Visit(s) by expert (if staggered) فترات زيارة الخبير</label>
                                <br>
                                <div class="row mt-2">
                                    <div class="col-md-5 row">
                                        <label style="margin-right: 20px;" for="from1">From</label>
                                        <input type="date" id="from1" name="from1" class="form-control col-md-8" placeholder="Enter date" style="margin-right: 20px;"  value="{{isset($data['from1'])? $data['from1'] : ''}}" >
                                    </div>
                                    <div class="ml-2 mr-2 col-md-5 row">
                                        <label style="margin-right: 20px;" for="to1">To</label>
                                        <input type="date" id="to1" name="to1" class="form-control col-md-8" placeholder="Enter date"  style="margin-right: 20px;" value="{{isset($data['to1'])? $data['to1'] : ''}}">
                                    </div>
                                </div>
                                <div class="row mt-2">
                                    <div class="col-md-5 row">
                                        <label style="margin-right: 20px;" for="from2">From</label>
                                        <input type="date" id="from2" name="from2" class="form-control col-md-8" placeholder="Enter date" style="margin-right: 20px;"  value="{{isset($data['from2'])? $data['from2'] : ''}}" >
                                    </div>
                                    <div class="ml-2 mr-2 col-md-5 row">
                                        <label style="margin-right: 20px;" for="to2">To</label>
                                        <input type="date" id="to2" name="to2" class="form-control col-md-8" placeholder="Enter date"  style="margin-right: 20px;" value="{{isset($data['to2'])? $data['to2'] : ''}}">
                                    </div>
                                </div>
                                <div class="row mt-2">
                                    <div class="col-md-5 row">
                                        <label style="margin-right: 20px;" for="from3">From</label>
                                        <input type="date" id="from3" name="from3" class="form-control col-md-8" placeholder="Enter date" style="margin-right: 20px;"  value="{{isset($data['from3'])? $data['from3'] : ''}}" >
                                    </div>
                                    <div class="ml-2 mr-2 col-md-5 row">
                                        <label style="margin-right: 20px;" for="to3">To</label>
                                        <input type="date" id="to3" name="to3" class="form-control col-md-8" placeholder="Enter date"  style="margin-right: 20px;" value="{{isset($data['to3'])? $data['to3'] : ''}}">
                                    </div>
                                </div>
                            </div>
                            
                            <h3 class="form_header_2" style="margin-top: 20px;">BUDGET PROPOSAL </h3>
                            <p>N.B.: International expert’s expenses (air ticket(s) and indemnities, etc.) must be included in the estimated expenditure below. ملاحظة: يجب تضمين نفقات الخبراء الدوليين (تذاكر الطيران والتعويضات ، وما إلى ذلك) في النفقات المقدرة أدناه.</p>
                            
                            <table style="margin-top: 20px;">
                                <tr>
                                    <th>Type of expenditure البند</th>
                                    <th>Budget (OMR) المبلغ</th>
                                </tr>
                                <tr>
                                    <td class="p-0"><input type="text" name="budget_proposal[0]" class="budget_proposal border-0" style="width: 100%;" value="{{isset($data['budget_proposal'][0])? $data['budget_proposal'][0] : ''}}"></td>
                                    <td class="p-0"><input type="text" name="budget[0]" class="budget border-0" value="{{isset($data['budget'][0])? $data['budget'][0] : ''}}"></td>
                                </tr>
                                <tr>
                                    <td class="p-0"><input type="text" name="budget_proposal[1]" class="budget_proposal border-0" value="{{isset($data['budget_proposal'][1])? $data['budget_proposal'][1] : ''}}"></td>
                                    <td class="p-0"><input type="text" name="budget[1]" class="budget border-0" value="{{isset($data['budget'][1])? $data['budget'][1] : ''}}"></td>
                                </tr>
                                <tr>
                                    <td class="p-0"><input type="text" name="budget_proposal[2]" class="budget_proposal border-0" value="{{isset($data['budget_proposal'][2])? $data['budget_proposal'][2] : ''}}"></td>
                                    <td class="p-0"><input type="text" name="budget[2]" class="budget border-0" value="{{isset($data['budget'][2])? $data['budget'][2] : ''}}"></td>
                                </tr>
                                <tr>
                                    <td class="p-0"><input type="text" name="budget_proposal[3]" class="budget_proposal border-0" value="{{isset($data['budget_proposal'][3])? $data['budget_proposal'][3] : ''}}"></td>
                                    <td class="p-0"><input type="text" name="budget[3]" class="budget border-0" value="{{isset($data['budget'][3])? $data['budget'][3] : ''}}"></td>
                                </tr>
                                <tr>
                                    <td class="p-0"><input type="text" name="budget_proposal[4]" class="budget_proposal border-0" value="{{isset($data['budget_proposal'][4])? $data['budget_proposal'][4] : ''}}"></td>
                                    <td class="p-0"><input type="text" name="budget[4]" class="budget border-0" value="{{isset($data['budget'][4])? $data['budget'][4] : ''}}"></td>
                                </tr>
                                <tr>
                                    <td class="p-0"><input type="text" name="budget_proposal[5]" class="budget_proposal border-0" value="{{isset($data['budget_proposal'][5])? $data['budget_proposal'][5] : ''}}"></td>
                                    <td class="p-0"><input type="text" name="budget[5]" class="budget border-0" value="{{isset($data['budget'][5])? $data['budget'][5] : ''}}"></td>
                                </tr>
                                <tr>
                                    <td class="p-0"><input type="text" name="budget_proposal[6]" class="budget_proposal border-0" value="{{isset($data['budget_proposal'][6])? $data['budget_proposal'][6] : ''}}"></td>
                                    <td class="p-0"><input type="text" name="budget[6]" class="budget border-0" value="{{isset($data['budget'][6])? $data['budget'][6] : ''}}"></td>
                                </tr>
                                <tr>
                                    <td class="p-0"><input type="text" name="budget_proposal[7]" class="budget_proposal border-0" value="{{isset($data['budget_proposal'][7])? $data['budget_proposal'][7] : ''}}"></td>
                                    <td class="p-0"><input type="text" name="budget[7]" class="budget border-0" value="{{isset($data['budget'][7])? $data['budget'][7] : ''}}"></td>
                                </tr>
                                <tr>
                                    <td class="p-0"><input type="text" name="budget_proposal[8]" class="budget_proposal border-0" value="{{isset($data['budget_proposal'][8])? $data['budget_proposal'][8] : ''}}"></td>
                                    <td class="p-0"><input type="text" name="budget[8]" class="budget border-0" value="{{isset($data['budget'][8])? $data['budget'][8] : ''}}"></td>
                                </tr>
                                <tr>
                                    <td class="p-0"><input type="text" name="budget_proposal[9]" class="budget_proposal border-0" value="{{isset($data['budget_proposal'][9])? $data['budget_proposal'][9] : ''}}"></td>
                                    <td class="p-0"><input type="text" name="budget[9]" class="budget border-0" value="{{isset($data['budget'][9])? $data['budget'][9] : ''}}"></td>
                                </tr>
                                <tr>
                                    <td class="p-0"><input type="text" name="budget_proposal[10]" class="budget_proposal border-0" value="{{isset($data['budget_proposal'][10])? $data['budget_proposal'][10] : ''}}"></td>
                                    <td class="p-0"><input type="text" name="budget[10]" class="budget border-0" value="{{isset($data['budget'][10])? $data['budget'][10] : ''}}"></td>
                                </tr>
                                <tr>
                                    <td class="p-0"><input type="text" name="budget_proposal[11]" class="budget_proposal border-0" value="{{isset($data['budget_proposal'][11])? $data['budget_proposal'][11] : ''}}"></td>
                                    <td class="p-0"><input type="text" name="budget[11]" class="budget border-0" value="{{isset($data['budget'][11])? $data['budget'][11] : ''}}"></td>
                                </tr>
                                <tr>
                                    <td>الاجماليTOTAL</td>
                                    <td class="p-0"><input type="text" name="budget_total" class="budget border-0" value="{{isset($data['budget_total'])? $data['budget_total'] : ''}}"></td>
                                </tr>
                            </table>

                            <div class="col-md-12 row" style="margin-top: 20px;">
                                <div class="form-group col-md-12">
                                    <label for="exampleInputEmail1">Has your NF already submitted all the relevant technical details to its respective IF? هل تم التنسيق مع الاتحاد الدولي المعني حول تفاصيل طلب هذه الدورة</label>
                                    <input type="radio" id="yes" name="technical_details"  value="yes" {{isset($data['technical_details']) && $data['technical_details']  == "yes" ? 'checked' : ''}} >
                                    <label for="yes">Yes</label>
                                    <input type="radio" id="no" name="technical_details" value="no" {{isset($data['technical_details']) && $data['technical_details']  == "no" ? 'checked' : ''}}>
                                    <label for="no">No</label>
                                </div>
                            </div>
                            
                            <h3 class="form_header_2" style="margin-top: 20px;">PROPOSED EXPERT الخبير المقترح  </h3>
                            <div class="col-md-12 row" style="margin-top: 20px;">
                                <div class="form-group col-md-6">
                                    <label for="exampleInputEmail1">Family Name اسم العائلة</label>
                                    <input type="text" name="family_name" class="form-control" placeholder="Family Name" value="{{isset($data['family_name'])? $data['family_name'] : ''}}">
                                </div>
                                <div class="form-group col-md-6">
                                    <label for="exampleInputEmail1">Given Name(s) الاسم الأول</label>
                                    <input type="text" name="given_name" class="form-control" placeholder="Given Name" value="{{isset($data['given_name'])? $data['given_name'] : ''}}">
                                </div>
                            </div>
                            <div class="col-md-12 row">
                                <div class="form-group col-md-6">
                                    <label for="exampleInputEmail1">Date of Birth تاريخ الميلاد </label>
                                    <input type="date" name="date_of_birth" class="form-control"  value="{{isset($data['date_of_birth'])? $data['date_of_birth'] : ''}}">
                                </div>
                                <div class="form-group col-md-6">
                                    <label for="exampleInputEmail1">Nationality الجنسية</label>
                                    <input type="text" name="nationality" class="form-control" placeholder="Nationality" value="{{isset($data['nationality'])? $data['nationality'] : ''}}">
                                </div>
                            </div>
                            <div class="col-md-12 row">
                                <div class="form-group col-md-6">
                                    <label for="exampleInputEmail1">Genderالجنس</label>
                                    <input type="radio" id="male" name="gender"  value="male" {{isset($data['gender']) && $data['gender']  == "male" ? 'checked' : ''}} >
                                    <label for="male">Male</label>
                                    <input type="radio" id="female" name="gender" value="female" {{isset($data['gender']) && $data['gender']  == "female" ? 'checked' : ''}}>
                                    <label for="female">Female</label>
                                </div>
                                <div class="form-group col-md-6">
                                    <label for="exampleInputEmail1">Current level المستوى الحالي</label>
                                    <input type="text" name="current_level" class="form-control" placeholder="Current Level" value="{{isset($data['current_level'])? $data['current_level'] : ''}}">
                                </div>
                            </div>
                            <div class="col-md-12 row" style="margin-top: 20px;">
                                <div class="form-group col-md-6">
                                    <label for="exampleInputEmail1">Residence الإقامة (المدينة / الدولة) (city, country)</label>
                                    <input type="text" name="residence" class="form-control" placeholder="Residence" value="{{isset($data['residence'])? $data['residence'] : ''}}">
                                </div>
                                <div class="form-group col-md-6">
                                    <label for="exampleInputEmail1">Emailالبريد الالكتروني </label>
                                    <input type="email" name="email" class="form-control" placeholder="Email" value="{{isset($data['email'])? $data['email'] : ''}}">
                                </div>
                            </div>
                            <div class="col-md-12 row" style="margin-top: 20px;">
                                <div class="form-group col-md-6">
                                    <label for="exampleInputEmail1">Telephoneالهاتف  </label>
                                    <input type="number" name="telephone" class="form-control" placeholder="Telephone" value="{{isset($data['telephone'])? $data['telephone'] : ''}}">
                                </div>
                                <div class="form-group col-md-6">
                                    <label for="exampleInputEmail1">Mobileالجوال </label>
                                    <input type="number" name="mobile" class="form-control" placeholder="Mobile" value="{{isset($data['mobile'])? $data['mobile'] : ''}}">
                                </div>
                            </div>

                            <h3 class="form_header_2" style="margin-top: 20px;">EDUCATION & DIPLOMAS المستوى التعليمي والمؤهلات</h3>
                            <table style="margin-top: 20px;">
                                <tr>
                                    <th>Year السنة </th>
                                    <th>Training التدريب </th>
                                    <th>Diplomas awarded شهادات الدبلوم</th>
                                </tr>
                                <tr>
                                    <td class="p-0"><input type="text" name="year[0]" class="budget_proposal border-0" style="width: 100%;" value="{{isset($data['year'][0])? $data['year'][0] : ''}}"></td>
                                    <td class="p-0"><input type="text" name="training[0]" class="budget border-0" value="{{isset($data['training'][0])? $data['training'][0] : ''}}"></td>
                                    <td class="p-0"><input type="text" name="diplomas_awarded[0]" class="budget border-0" value="{{isset($data['diplomas_awarded'][0])? $data['diplomas_awarded'][0] : ''}}"></td>
                                </tr>
                                <tr>
                                    <td class="p-0"><input type="text" name="year[1]" class="budget_proposal border-0" style="width: 100%;" value="{{isset($data['year'][1])? $data['year'][1] : ''}}"></td>
                                    <td class="p-0"><input type="text" name="training[1]" class="budget border-0" value="{{isset($data['training'][1])? $data['training'][1] : ''}}"></td>
                                    <td class="p-0"><input type="text" name="diplomas_awarded[1]" class="budget border-0" value="{{isset($data['diplomas_awarded'][1])? $data['diplomas_awarded'][1] : ''}}"></td>
                                </tr>
                                <tr>
                                    <td class="p-0"><input type="text" name="year[2]" class="budget_proposal border-0" style="width: 100%;" value="{{isset($data['year'][2])? $data['year'][2] : ''}}"></td>
                                    <td class="p-0"><input type="text" name="training[2]" class="budget border-0" value="{{isset($data['training'][0])? $data['training'][2] : ''}}"></td>
                                    <td class="p-0"><input type="text" name="diplomas_awarded[2]" class="budget border-0" value="{{isset($data['diplomas_awarded'][2])? $data['diplomas_awarded'][2] : ''}}"></td>
                                </tr>
                            </table>

                            <h3 class="form_header_2" style="margin-top: 20px;">SPORTS EXPERIENCE الخبرات الرياضية </h3>
                            <table style="margin-top: 20px;">
                                <tr>
                                    <th>Year السنة </th>
                                    <th>Clubs, athletes coached, past achievements, etc. أندية ، رياضيون مدربون ، إنجازات سابقة ، إلخ</th>
                                </tr>
                                <tr>
                                    <td class="p-0"><input type="text" name="sports_year[0]" class="budget_proposal border-0" style="width: 100%;" value="{{isset($data['sports_year'][0])? $data['sports_year'][0] : ''}}"></td>
                                    <td class="p-0"><input type="text" name="past_achievements[0]" class="budget border-0" value="{{isset($data['past_achievements'][0])? $data['past_achievements'][0] : ''}}"></td>
                                </tr>
                                <tr>
                                    <td class="p-0"><input type="text" name="sports_year[1]" class="budget_proposal border-0" style="width: 100%;" value="{{isset($data['sports_year'][1])? $data['sports_year'][1] : ''}}"></td>
                                    <td class="p-0"><input type="text" name="past_achievements[1]" class="budget border-0" value="{{isset($data['past_achievements'][1])? $data['past_achievements'][1] : ''}}"></td>
                                </tr>
                                <tr>
                                    <td class="p-0"><input type="text" name="sports_year[2]" class="budget_proposal border-0" style="width: 100%;" value="{{isset($data['sports_year'][2])? $data['sports_year'][2] : ''}}"></td>
                                    <td class="p-0"><input type="text" name="past_achievements[2]" class="budget border-0" value="{{isset($data['past_achievements'][2])? $data['past_achievements'][2] : ''}}"></td>
                                </tr>
                            </table>

                            <h3 class="form_header_2" style="margin-top: 20px;">NATIONAL COORDINATOR(IF ALREADY KNOWN) المنسق الوطني للبرنامج – اذا كان متوافرا  </h3>
                            
                            <div class="col-md-12 row" style="margin-top: 20px;">
                                <div class="form-group col-md-6">
                                    <label for="exampleInputEmail1">Family Name اسم العائلة</label>
                                    <input type="text" name="national_family_name" class="form-control" placeholder="Family Name" value="{{isset($data['national_family_name'])? $data['national_family_name'] : ''}}">
                                </div>
                                <div class="form-group col-md-6">
                                    <label for="exampleInputEmail1">Given Name(s) الاسم الأول</label>
                                    <input type="text" name="national_given_name" class="form-control" placeholder="Given Name" value="{{isset($data['national_given_name'])? $data['national_given_name'] : ''}}">
                                </div>
                            </div>
                            <div class="col-md-12 row">
                                <div class="form-group col-md-6">
                                    <label for="exampleInputEmail1">Nationality الجنسية</label>
                                    <input type="text" name="national_nationality" class="form-control" placeholder="Nationality" value="{{isset($data['national_nationality'])? $data['national_nationality'] : ''}}">
                                </div>
                                <div class="form-group col-md-6">
                                    <label for="exampleInputEmail1">Title within the NF or NOC  المسمى</label>
                                    <input type="text" name="national_noc" class="form-control" placeholder="Title within the NF or NOC" value="{{isset($data['national_noc'])? $data['national_noc'] : ''}}">
                                </div>
                            </div>
                            <div class="col-md-12 row" style="margin-top: 20px;">
                                <div class="form-group col-md-6">
                                    <label for="exampleInputEmail1">Emailالبريد الالكتروني </label>
                                    <input type="email" name="national_email" class="form-control" placeholder="Email" value="{{isset($data['national_email'])? $data['national_email'] : ''}}">
                                </div>
                                <div class="form-group col-md-6">
                                    <label for="exampleInputEmail1">Mobileالجوال </label>
                                    <input type="number" name="mobile" class="form-control" placeholder="Mobile" value="{{isset($data['mobile'])? $data['mobile'] : ''}}">
                                </div>
                            </div>

                            <h3 class="form_header_2" style="margin-top: 20px;">ATTACHMENTS REQUIRED المرفقات المطلوبة  </h3>  

                            <table style="margin-top: 20px;">
                                <tr>
                                    <td>Detailed action plan خطة العمل المفصلة </td>
                                    <td>
                                        <div class="row">
                                        تحميل مرفق
                                        <input class="form-check-input" type="checkbox" name="detailed_action_plan" value="detailed_action_plan" {{isset($data['detailed_action_plan']) && $data['detailed_action_plan']  =="detailed_action_plan" ? 'checked' : ''}}>
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <td>Overall and detailed budget الموازنة الشاملة والمفصلة </td>
                                    <td>
                                        <div class="row">
                                        تحميل مرفق <input class="form-check-input" type="checkbox" name="overall_detailed_budget" value="overall_detailed_budget" {{isset($data['overall_detailed_budget']) && $data['overall_detailed_budget']  =="overall_detailed_budget " ? 'checked' : ''}}>
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <td>Curriculum Vitae of the proposed expert (where applicable) السيرة الذاتية ااخبير المقترح ان وجد  </td>
                                    <td> 
                                        <div class="row">
                                        تحميل مرفق <input class="form-check-input" type="checkbox" name="curriculum_vitae" value="curriculum_vitae" {{isset($data['curriculum_vitae']) && $data['curriculum_vitae']  =="curriculum_vitae" ? 'checked' : ''}}></div>
                                    </td>
                                </tr>
                                <tr>
                                    <td>Acceptance letter from the expert خطاب قبول من الخبير  </td>
                                    <td> <div class="row">تحميل مرفق <input class="form-check-input" type="checkbox" name="acceptance_letter" value="acceptance_letter" {{isset($data['acceptance_letter']) && $data['acceptance_letter']  =="acceptance_letter" ? 'checked' : ''}}></div></td>
                                </tr>
                            </table>

                            <p>يرفق الطلب مع رسالة تغطية من الاتحاد / اللجنة ويتم تحميلها عبر النظام ويتم ارسال الأصل الى البريد الرسمي للجنة الأولمبية العمانية موجهة الى الأمين العام</p>

                        </div>
                        <!-- /.card-body -->
                        <div class="card-footer">
                            @if (( \Auth::user()->hasAnyRole(['User']) && !isset($data) ) || (\Auth::user()->hasAnyRole(['User']) && (isset($dataUserApplications) && $dataUserApplications['status'] == 'request not completed')))
                                @if(isset($data))
                                <button type="submit" class="btn btn-primary">@lang('custom.update')</button>
                                @else
                                <button type="submit" class="btn btn-primary">@lang('custom.save')</button>
                                @endif
                            @endif
                        </div>
                    </form>
                </div>

            </div>

            
        </div>

    </div>
</section>